import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { TrackOrderListService } from 'app/services/trackOrderList/trackorderlist';
import { saveAs } from 'file-saver';
import { PurchaseOrderListService } from 'app/services/purchaseOrderList/purchaseorderlist.service';
import { InternalportalserviceService } from 'app/services/internalportal/internalportalservice.service';
import { LoaderService } from 'app/services/LoaderService/loader.service';
import * as moment from 'moment/moment';
import { DialogModelComponent } from 'app/components/dialogcomponent/dialog-model/dialog-model.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
// import { DialogModelComponent } from 'app/dialog-model/dialog-model.component';
declare var $: any;
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-internal-invalid-invoice',
  templateUrl: './internal-invalid-invoice.component.html',
  styleUrls: ['./internal-invalid-invoice.component.css']
})
export class InternalInvalidInvoiceComponent implements OnInit {
  @ViewChild(DialogModelComponent) dialogBox: DialogModelComponent;
  public invalidinvoice = new FormGroup({
    POrealNumber: new FormControl(''),
    InvoiceNumber: new FormControl(''),
    fromDate: new FormControl(''),
    toDate: new FormControl(''),
    POOrderNumber: new FormControl(''),
    POlineitemNumber: new FormControl(''),
    Plant: new FormControl(''),
    withoutpo: new FormControl(false)
    // searchtype: new FormControl('')
    // paymentMethod: new FormControl('', Validators.required),
    // paymentStatus: new FormControl('', Validators.required),
    // Topicker: new FormControl('', Validators.required)
  })
  // constructor() { }

  // ngOnInit(): void {
  // }
  historic: string = 'false';
  currstatus: any = 'P';
  innum: string = 'NA';
  ponum: string = 'NA';
  fd: string = 'NA';
  td: string = 'NA';
  plant: any = "NA";
  totalItems: any;
  pendingPo :any = 0;
  pageSize: number = 50;
  paginationpagenumber:number =1;
  endpagenumber: number = 1;
  mindate: any;
  maxdate: any;
  topic: any;
  uniquePONumber: any;
  uniqueInvNumber: any;
  recipientEmail: any;
  remarklength: number = 160;
  mintodate: Date;
  allinvlist: any[];
  invoiceData1: any = [];
  searchList: any = [];
  invoiceData: any = [];
  invoiceDatawopo: any = []
  invoiceCountAsPerStatus:any=[];
  messageList: any = [];
  test: any = [];
  PlantList: any = [];
  tempPlantList: any = []; 
   filteredinvoiceData: any = [];
  filteredponumberData: any = [];
  filtereddate: any = [];
  pgNolist: any[];
  filteredlineitemnumber: any[];
  filteredordernumber: any[];
  disableoff: boolean = false;
  disablenext: boolean = false; 
  disable: boolean = false;
  disableprevious: boolean = false;
  equalfound: boolean = false;
  headdisableoff: boolean = false;
  todateerror: boolean = false;
  fromdateerror: boolean = false;
  plantpresent: boolean = false;
   approximatecheck: boolean = false;
   invoicenumberpresent: boolean = false;
   ponumberpresent: boolean = false;
   fromtodatepresent: boolean = false;
   validate: boolean = true;
   checkboxvalue: string;
   message: string;
  pageno=1;
  constructor(public dialog: MatDialog, private router: Router, private route: ActivatedRoute, private purchaseOrderListService: PurchaseOrderListService,
    private trackOrderListService: TrackOrderListService, private toastr: ToastrService, private InternalportalserviceService: InternalportalserviceService,
    private loaderservice: LoaderService) { }

  ngOnInit(): void {
// this. getInvoiceData(this.pageno); 
alert();
    this.getInvalidInvoice();
   
  }
  getInvalidInvoice(){
    alert("Hi invalid")
    this.pageno = 1;

    this.InternalportalserviceService.getInternalInvalidinvoice(this.pageno,'NA','NA','NA','NA','NA','NA').subscribe(res => {
  console.log(res);
 this.invoiceData1 =  res[0].invoiceData;
console.log(this.invoiceData1)
    })
  }
  openAdavnceSearch() {
    let advanceSearcBox = document.getElementById("advanceSearcBox");
    let closeArrow = document.getElementById("closeArrow");
    let openArrow = document.getElementById("openArrow");
    if (advanceSearcBox.style.display === "none") {
      advanceSearcBox.style.display = "block";
      closeArrow.style.display = "block";
      openArrow.style.display = "none";
    } else {
      advanceSearcBox.style.display = "none";
      openArrow.style.display = "block";
      closeArrow.style.display = "none";
    }
  }
  checkbox(){
    var story = '';
    var negstory = '';
    $(".chb").change(function() {
      var status = $(this).prop("checked");
      var negstatus = $(this).prop("unchecked");
     
      $(".chb").prop('checked', false);
      $(this).prop('checked', true);
      if (status === false) {
        $(this).prop('checked', false);
        // this.headdisableoff = true;
      } 
      else{
        // this.headdisableoff = false;
      }
     
      story = $('input[type=checkbox]:checked').val();
      negstory =$("input:checkbox:not(:checked)").val()
      // negstory = $('input[type=checkbox]:checked').val();
      console.log("checked value",story) ;
      console.log("Unchecked value",negstory) ;
      console.log("status is here ==> "+status);
      console.log("status is here uncheck ==> "+negstatus);
     });  
      
     setTimeout(() => {
      this.checkboxvalue = story;
      console.log("checked value..........",this.checkboxvalue) ;
       if(this.checkboxvalue == "ASWP"){
         this.currstatus = "ASWP";
      this.headdisableoff = true;

    }else if(this.checkboxvalue == "ASSQ" || negstory == 'ASWP'){
      this.headdisableoff = false;
      this.currstatus = "ASSQ";
    }
     }, 50);
     
     
    

    }


    trackPayment(searchponumber, searchlineitemnumber, searchordernumber) {
      alert("search")
      this.historic = "false";
      this.paginationpagenumber = 1;
      this.disableprevious = true;
      // this.mPageNo = 1;
     
      if(this.checkboxvalue == "ASWP"){
        this.currstatus = 'ASWP';
        this.disableoff = true;
  
      }else if(this.checkboxvalue == "ASSQ"){
        this.disableoff = false;
        this.currstatus = 'ASSQ';
      }else{
        this.currstatus = 'AS';
      }
     
  
      this.invoiceData = [];
      this.approximatecheck = true;
      console.log("this.searchordernumber ==>" + searchordernumber);
      // this.loaderservice.show();
      this.invoiceData = [];
      this.filteredinvoiceData = [];
      this.filteredponumberData = [];
      this.filtereddate = [];
      this.filteredlineitemnumber = [];
      this.filteredordernumber = [];
      this.invoicenumberpresent = false;
      this.plantpresent = false;
      this.ponumberpresent = false;
      this.fromtodatepresent = false;
      console.log(searchponumber, 'searchponumber');
      if (searchponumber != '') {
        this.invalidinvoice.controls.POrealNumber.setValue(searchponumber);
      }
      if (searchlineitemnumber != '') {
        this.invalidinvoice.controls.POlineitemNumber.setValue(searchlineitemnumber);
      }
      if (searchordernumber != '') {
        this.invalidinvoice.controls.POOrderNumber.setValue(searchordernumber);
      }
      
      if (this.invalidinvoice.controls['Plant'].value) {
        console.log("this.invalidinvoice.controls['Plant'].value "+this.invalidinvoice.controls['Plant'].value);
        for(var b =0;b<this.tempPlantList.length;b++)
      {
        console.log("this.tempPlantList[b].PLANTNAME "+this.tempPlantList[b].PLANTNAME);
        if(this.tempPlantList[b].PLANTNAME == this.invalidinvoice.controls['Plant'].value.trim())
        {
          this.plant = this.tempPlantList[b].PLANTCODE;
        }
      }
        this.plantpresent = true;
        // this.plant = this.invoiceList.controls['Plant'].value.trim();
      }
      else {
        this.plant = 'NA';
      }
      if (this.invalidinvoice.controls['InvoiceNumber'].value) {
        this.invoicenumberpresent = true;
        this.innum = this.invalidinvoice.controls['InvoiceNumber'].value.trim();
      }
      else {
        this.innum = 'NA';
      }
      if (this.invalidinvoice.controls['POrealNumber'].value) {
        this.ponumberpresent = true;
        this.ponum = this.invalidinvoice.controls['POrealNumber'].value.trim();
      }
      else {
        this.ponum = 'NA';
      }
      if (this.invalidinvoice.controls['fromDate'].value) {
        this.fromtodatepresent = true;
        this.fd = moment(new Date(this.invalidinvoice.controls['fromDate'].value)).format("DD/MM/YYYY").trim();
        this.td = moment(new Date(this.invalidinvoice.controls['toDate'].value)).format("DD/MM/YYYY").trim();
      }
      else {
        this.fd = 'NA';
        this.td = 'NA';
      }
  
      this.trackOrderListService.getInvoiceData(this.paginationpagenumber, this.currstatus, 
        this.innum,this.ponum, this.fd, this.td,this.plant).subscribe(res => {
          let advanceSearcBox = document.getElementById("advanceSearcBox");
          let closeArrow = document.getElementById("closeArrow");
          let openArrow = document.getElementById("openArrow");
          advanceSearcBox.style.display = "none";
          openArrow.style.display = "block";
          closeArrow.style.display = "none";
          // this.invoiceList.reset();
          if (this.disableoff == true) {
            if(res[0].invoiceCountAsPerStatus)
            {
              this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
              if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
                this.pendingPo = this.invoiceCountAsPerStatus.M;
              }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
                this.pendingPo = this.invoiceCountAsPerStatus.P;
              }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
                this.pendingPo = 0;
              }else{
                this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
              }
            }
            if (res[0].message1 == "Sucessinvlist1") {
              this.invoiceData = res[0].invoiceDataWOPO;
              // this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
              // if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
              //   this.pendingPo = this.invoiceCountAsPerStatus.M;
              // }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
              //   this.pendingPo = this.invoiceCountAsPerStatus.P;
              // }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
              //   this.pendingPo = 0;
              // }else{
              //   this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
              // }        // this.invoiceDatawopo = res[0].invoiceDataWOPO;
              this.totalItems = res[0].invoicewopopages;
              this.endpagenumber = Math.ceil((Number(res[0].invoicewopopages)/this.pageSize))
              if(Number(res[0].invoicewopopages)/this.paginationpagenumber <= this.pageSize)
              {
                this.disablenext = true;
              }
              else
              {
                this.disablenext = false;
              }
            }
            else {
              this.invoiceData = [];
              this.totalItems = 0;
            }
          }
          else {
            if (res[0].message == "Sucessinvlist") {
              if(res[0].invoiceCountAsPerStatus)
              {
                this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
                if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
                  this.pendingPo = this.invoiceCountAsPerStatus.M;
                }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
                  this.pendingPo = this.invoiceCountAsPerStatus.P;
                }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
                  this.pendingPo = 0;
                }else{
                  this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
                }
              }
              this.invoiceData = res[0].invoiceData;
              // this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
              // if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
              //   this.pendingPo = this.invoiceCountAsPerStatus.M;
              // }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
              //   this.pendingPo = this.invoiceCountAsPerStatus.P;
              // }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
              //   this.pendingPo = 0;
              // }else{
              //   this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
              // }        // this.invoiceDatawopo = res[0].invoiceDataWOPO;
              this.totalItems = res[0].invoicelistpages;
              this.endpagenumber = Math.ceil((Number(res[0].invoicelistpages)/this.pageSize))
              if(Number(res[0].invoicelistpages)/this.paginationpagenumber <= this.pageSize)
              {
                this.disablenext = true;
              }
              else
              {
                this.disablenext = false;
              }
            }
            else {
              this.invoiceData = [];
              this.totalItems = 0;
            }
          }
         
        });
     
    }

  keyPressAlphanumeric(event): Boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)
      || (charCode >= 48 && charCode <= 57) || charCode == 32 ||
      charCode == 45 || charCode == 47 || charCode == 92) {
      return true;
    }
    return false;
  }
  getuniqueinvoice(array) {
    for (var i = 0; i < this.invoiceData1.length; i++) {
      this.equalfound = false;
      var tempo = this.invoiceData1[i].PO_NUMBER;
      var tempinvo = this.invoiceData1[i].INVOICENUMBER;
      if (i + 1 != this.invoiceData1.length) {
        for (var j = i + 1; j < this.invoiceData1.length; j++) {

          if (tempo == this.invoiceData1[j].PO_NUMBER &&
            tempinvo == this.invoiceData1[j].INVOICENUMBER) {
            console.log("innini if");
            this.equalfound = true;
            break;
          }
        }

      }
      if (this.equalfound == false) {
        console.log("innini push");
        this.invoiceData.push(this.invoiceData1[i])
      }
    }
    return this.invoiceData;
  }
  onDateChange() {
    if (this.invalidinvoice.controls['fromDate'].value) {
      if (this.invalidinvoice.controls['toDate'].value) {
        this.disable = false;
        this.fromdateerror = false;
        this.todateerror = false;
      }
      else {
        this.todateerror = true;
        this.fromdateerror = false;
        this.disable = true;
      }
      this.mintodate = new Date(this.invalidinvoice.controls['fromDate'].value);
    }
    else if (this.invalidinvoice.controls['toDate'].value) {
      if (this.invalidinvoice.controls['fromDate'].value) {
        this.disable = false;
        this.fromdateerror = false;
        this.todateerror = false;
      }
      else {
        this.fromdateerror = true;
        this.todateerror = false;
        this.disable = true;
      }
    }
    this.maxdate = new Date(this.invalidinvoice.controls['toDate'].value);
  
   
  }
  ResetData() {
    this.invalidinvoice.reset();
    this.invalidinvoice.controls.InvoiceNumber.setValue("");
    this.invalidinvoice.controls.POrealNumber.setValue("");
    // this.invoiceList.controls.duration.setValue("");
    this.invalidinvoice.controls.fromDate.setValue("");
    this.invalidinvoice.controls.toDate.setValue("");
    this.invalidinvoice.controls.Plant.setValue("");

    this.todateerror = false;
    this.disable = false;
  }

  
  getPlantData(e) {
    this.PlantList = [];

    this.trackOrderListService.getPlanCode(e.target.value.toUpperCase()).subscribe(res => {
      this.tempPlantList = res[0].grnbasedonpo;
      // for (var i = 0; i < this.tempPlantList.length; i++) {
      //   // var plantdata = this.tempPlantList[i].PLANTCODE + ' - ' + this.tempPlantList[i].PLANTNAME
      //   var plantdata = this.tempPlantList[i].PLANTCODE;
      //   this.PlantList.push(plantdata);
        
      // }
      console.log(this.PlantList, 'PlantList')
    });
  }
  // getInvoiceData(pageno) {
  //   // this.loaderservice.show();
  //   this.disableprevious = true;
   
  //   this.invoiceData1 = [];
  //   this.invoiceData = [];

  //   this.trackOrderListService.getInvoiceData(pageno, this.currstatus, 'NA', 'NA', 'NA', 'NA',this.plant).subscribe(res => {
  //     if(res[0].invoiceCountAsPerStatus)
  //     {

        
  //       alert("hi invoicedata")
  //       this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
  //       if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
  //         this.pendingPo = this.invoiceCountAsPerStatus.M;
  //       }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
  //         this.pendingPo = this.invoiceCountAsPerStatus.P;
  //       }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
  //         this.pendingPo = 0;
  //       }else{
  //         this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
  //       }
        
       
  //     }
  

  //     if(res[0].message="Sucessinvlist"){
  //       this.invoiceData1 = res[0].invoiceData;
    
  //       console.log("this.invoiceData1.length", this.invoiceData1);
  //       for (var n = 0; n < this.invoiceData1.length; n++) {
  //         if (this.invoiceData1[n].STATUS == "INV") {
            
  //           this.test.push(this.invoiceData1[n]);
  //         }
  //       }
  //       console.log("this.invoiceData1[n] ==> ", this.test);
  //       this.getuniqueinvoice(this.invoiceData1);

  //     }
  //     if (this.invoiceData.length > 0) {
  //       setTimeout(() => {
  //         // this.getmessageColor();
  //       }, 250);

  //     }
    
  //   });
  //   // this.loaderservice.show();

  //   // this.loaderservice.hide();
  //   // this.invoiceList.reset();
  // }



  getmessageStatus() {
    // getReadStatus()
    this.purchaseOrderListService.getChatStatus().subscribe(res => {
      if (res[0].message != "No Data Found for given Vendor Id") {
        console.log("is Data Coming??", res[0].poQueryList);
        // this.statusList = res[0].poQueryList
        this.loaderservice.hide();
      }
      else {
        // this.statusList = [];
      }

    })
  }

  getInvoiceQuerry(ponumber, invoicenumber, contactpersonemailid) {
    console.log("inside", invoicenumber);

    this.recipientEmail = contactpersonemailid;
    sessionStorage.setItem("receiverMail", contactpersonemailid)
    // this.purchaseOrderListService.getMessages(invoicenumber).subscribe(res => {
    this.trackOrderListService.getInvMessages(ponumber, invoicenumber).subscribe(res => {
      console.log("resposne", res[0].message)
      this.messageList = [];
      this.topic = invoicenumber
      if (res[0].poQueryList[0] != undefined) {
        this.messageList = res[0].poQueryList
      }
      // else {
      //   this.messageList = res[0].message
      // }
      console.log(this.messageList)
    })
  }

  gettrackInvList(action) {
    this.loaderservice.show();
    this.invoiceData = [];
     if(action == 'PREV')
    {
      if(this.paginationpagenumber !=1)
      {
        this.paginationpagenumber = this.paginationpagenumber -1;
        if(this.paginationpagenumber == 1)
        {
          this.disableprevious = true;
        }
        else
        {
          this.disableprevious = false;
        }
      }
      else{
        return;
      }
      
    }
    else if(action == 'NEXT')
    {
      this.paginationpagenumber = this.paginationpagenumber +1;
      this.disableprevious = false;
      
    }
      else if(action == 'HOME')
      {
        this.paginationpagenumber = 1;
        this.disableprevious = true;

      }
      else if(action == 'END')
      {

      this.paginationpagenumber = this.endpagenumber;
      if(this.paginationpagenumber == 1)
      {
        this.disableprevious = true;
      }
      else
      {
        this.disableprevious = false;
      }
      }
    console.log("this.disableoff " + this.disableoff);
    console.log("this.ponum " + this.ponum);
    console.log("this.innum " + this.innum);
    if (this.currstatus == "AS") {
      this.trackOrderListService.getInvoiceData(this.paginationpagenumber, this.currstatus, this.innum, this.ponum, this.fd, this.td,this.plant).subscribe(res => {

       
        if (this.disableoff == true) {
          if(res[0].invoiceCountAsPerStatus)
          {
            this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
            if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
              this.pendingPo = this.invoiceCountAsPerStatus.M;
            }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = this.invoiceCountAsPerStatus.P;
            }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = 0;
            }else{
              this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
            }
          }
          if (res[0].message1 == 'Sucessinvlist1') {
            this.invoiceData = res[0].invoiceDataWOPO;
            if (this.invoiceData.length > 0) {
              for (let i = 0; i < this.invoiceData.length; i++) {
                this.invoiceData[i].TOTALAMOUNT = Number(this.invoiceData[i].TOTALAMOUNT)
                this.invoiceData[i].STATUS = "WP";
              }
              this.totalItems = res[0].invoicewopopages;
              if(Number(res[0].invoicewopopages)/this.paginationpagenumber <= this.pageSize)
            {
              this.disablenext = true;
            }
            else
            {
              this.disablenext = false;
            }
              // this.loaderservice.hide();
            }
            else {
              // this.loaderservice.hide();
              this.invoiceData = [];
              this.totalItems = 0;
            }

          }
        }
        else {
          if(res[0].invoiceCountAsPerStatus)
          {
            this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
            if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
              this.pendingPo = this.invoiceCountAsPerStatus.M;
            }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = this.invoiceCountAsPerStatus.P;
            }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = 0;
            }else{
              this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
            }
          }
          if (res[0].message == 'Sucessinvlist') {

            this.invoiceData = res[0].invoiceData;
          
            console.log("th list ==>" + JSON.stringify(this.invoiceData));
            // this.totalItems = this.invoiceData.length;
            this.totalItems = res[0].invoicelistpages;
            // this.loaderservice.hide();
            console.log("res[0].invoicelistpages "+res[0].invoicelistpages);
            console.log("this.paginationpagenumber "+this.paginationpagenumber);
            console.log("this.pageSize "+this.pageSize);
            if(Number(res[0].invoicelistpages)/this.paginationpagenumber <= this.pageSize)
            {
              this.disablenext = true;
            }
            else
            {
              this.disablenext = false;
            }
          }
          else {
            // this.loaderservice.hide();
            this.invoiceData = [];
            this.totalItems = 0;
          }

        }
        this.loaderservice.hide();
      });

    }
    else {
      this.trackOrderListService.getInvoiceData(this.paginationpagenumber, this.currstatus, 'NA', 'NA', 'NA', 'NA',this.plant).subscribe(res => {
        if (this.disableoff == true) {
          if(res[0].invoiceCountAsPerStatus)
          {
            this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
            if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
              this.pendingPo = this.invoiceCountAsPerStatus.M;
            }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = this.invoiceCountAsPerStatus.P;
            }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = 0;
            }else{
              this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
            }
          }
          if (res[0].message1 == 'Sucessinvlist1') {
            this.invoiceData = res[0].invoiceDataWOPO;
            
            if (this.invoiceData.length > 0) {
              for (let i = 0; i < this.invoiceData.length; i++) {
                this.invoiceData[i].TOTALAMOUNT = Number(this.invoiceData[i].TOTALAMOUNT)
                // .toFixed(2).replace(/\B(?=(?:(\d\d)+(\d)(?!\d))+(?!\d))/g, ',')
                this.invoiceData[i].STATUS = "WP";
              }
              this.totalItems = res[0].invoicewopopages;
              if(Number(res[0].invoicewopopages)/this.paginationpagenumber <= this.pageSize)
            {
              this.disablenext = true;
            }
            else
            {
              this.disablenext = false;
            }
              this.loaderservice.hide();
            }
            else {
              this.invoiceData = [];
              this.totalItems = 0;
              this.loaderservice.hide();
            }

          }

        }
        else {
          if(res[0].invoiceCountAsPerStatus)
          {
            this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
            if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M != null){
              this.pendingPo = this.invoiceCountAsPerStatus.M;
            }else if(this.invoiceCountAsPerStatus?.P != null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = this.invoiceCountAsPerStatus.P;
            }else if(this.invoiceCountAsPerStatus?.P == null && this.invoiceCountAsPerStatus?.M == null){
              this.pendingPo = 0;
            }else{
              this.pendingPo =  Number(this.invoiceCountAsPerStatus.P) + Number(this.invoiceCountAsPerStatus.M);
            }
          }
          if (res[0].message == 'Sucessinvlist') {

            this.invoiceData = res[0].invoiceData;
            // this.invoiceCountAsPerStatus = res[0].invoiceCountAsPerStatus;
           
            console.log("th list ==>" + JSON.stringify(this.invoiceData));
            // this.totalItems = this.invoiceData.length;
            this.totalItems = res[0].invoicelistpages;
            // this.loaderservice.hide();
            if(Number(res[0].invoicelistpages)/this.paginationpagenumber <= this.pageSize)
            {
              this.disablenext = true;
            }
            else
            {
              this.disablenext = false;
            }
          }
          else {
            // this.loaderservice.hide();
            this.invoiceData = [];
            this.totalItems = 0;
          }

        }
        this.loaderservice.hide();
      });

    }
  }

  ShowpopupMessage(ev) {
    $("#popupMessage").css("visibility", "visible");
    $("#popupMessage").css("opacity", "1");
    (<any>$("#popupComment").modal('show'));
    //     setTimeout(() => {
    //   $(".messageChatWrapper").stop().animate({ scrollTop: $(".messageChatWrapper")[0].scrollHeight}, 10);
    // },500);
  }
  ClosepopupMessage(ev) {
    $("#popupMessage").css("visibility", "hidden");
    $("#popupMessage").css("opacity", "0");
    this.getmessageStatus();
    // this.getInvoiceData();
  }
  checklength(type)
  {
    // console.log("in", $('#messagetext').val().length);
    if(type =='remark')
    {
      let count_elements = $('#messagetext').val().length;
      this.remarklength = 160-count_elements; 
    }
    
  }
  Check(message) {
    this.validate = true
    if (message.value != "" && message.value != " " && message.value != null && message.value.trim().length != 0) {
      this.validate = false;
    }


  }
  sendConfirmation(status, message, subject, topic) {
    // if (message == undefined || message == '')
    //   message = "Accepted";
    // console.log("AM I ???",status,message)
    // $(".messageChatWrapper").stop().animate({ scrollTop: $(".messageChatWrapper")[0].scrollHeight}, 1000);


    this.purchaseOrderListService.submitInvoiceChat("", this.uniquePONumber, this.uniqueInvNumber, status, message, subject, topic).subscribe(res => {

      if (res[0].message == "Success") {
        //  this.getQuerry(topic,'')
        // this.message = ' ';
        this.messageList = [];
        this.validate = true;
        this.message = "";
        this.trackOrderListService.getInvMessages(this.uniquePONumber, this.uniqueInvNumber).subscribe(res => {
          console.log("resposne", res[0].poQueryList)
          this.topic = topic
          if (res[0].poQueryList[0] != undefined) {
            this.messageList = res[0].poQueryList
          }
          else {
            this.messageList = res[0].message
          }
          console.log(this.messageList)
        })
      }
    })
  }
 multiPOData(invoicenumber, ponumber, creditnote, multiponumber) {
 
    if(multiponumber == undefined)
    {
      multiponumber = ponumber;
      this.router.navigate(['./trackInvoiceDetails'], { queryParams: { order: btoa(invoicenumber), po: btoa(ponumber), credit: btoa(creditnote) } });
    }
    else
    {
      this.router.navigate(['./trackMultiPODetails'], { queryParams: { order: btoa(invoicenumber), po: btoa(ponumber), credit: btoa(creditnote), mpo: btoa(multiponumber)  } });
    }
  }
  

}
